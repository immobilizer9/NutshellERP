const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

async function main() {
  await prisma.school.deleteMany();

  const stages = [
    "LEAD",
    "CONTACTED",
    "VISITED",
    "PROPOSAL_SENT",
    "NEGOTIATION",
    "CLOSED_WON",
    "CLOSED_LOST",
  ];

  const cities = ["Kolkata", "Delhi", "Mumbai", "Bangalore", "Siliguri"];

  for (let i = 1; i <= 25; i++) {
    await prisma.school.create({
      data: {
        name: `School ${i}`,
        address: `Address ${i}`,
        city: cities[i % cities.length],
        state: "West Bengal",
        latitude: 22.5 + Math.random(),
        longitude: 88.3 + Math.random(),
        contactPerson: `Principal ${i}`,
        contactPhone: `90000000${i}`,
        pipelineStage: stages[i % stages.length],
      },
    });
  }

  console.log("✅ Dummy schools inserted");
}

main()
  .catch((e) => console.error(e))
  .finally(async () => {
    await prisma.$disconnect();
  });